import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fakepath',
  templateUrl: './fakepath.component.html',
  styleUrls: ['./fakepath.component.css']
})
export class FakepathComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
