# ShareApp

1> Npm install
2> (client) ng serve

3> backend npm start
